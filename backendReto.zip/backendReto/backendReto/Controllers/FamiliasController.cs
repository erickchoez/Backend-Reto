﻿using backendReto.Data;
using backendReto.Dtos;
using backendReto.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace backendReto.Controllers;

[ApiController]
[Route("api/[controller]")]
public class FamiliasController : ControllerBase
{
    private readonly AppDbContext _db;
    public FamiliasController(AppDbContext db) => _db = db;

    [HttpGet]
    public async Task<ActionResult<IEnumerable<FamiliaDto>>> Get()
        => Ok(await _db.Familias
            .Select(f => new FamiliaDto(f.IdFamilia, f.Codigo, f.Nombre, f.Activo))
            .ToListAsync());

    [HttpGet("{id:int}")]
    public async Task<ActionResult<FamiliaDto>> GetById(int id)
    {
        var f = await _db.Familias.FindAsync(id);
        return f is null ? NotFound() : Ok(new FamiliaDto(f.IdFamilia, f.Codigo, f.Nombre, f.Activo));
    }

    [HttpPost]
    public async Task<ActionResult<FamiliaDto>> Post([FromBody] FamiliaCreateUpdateDto dto)
    {
        if (await _db.Familias.AnyAsync(x => x.Codigo == dto.Codigo))
            return Conflict("Código de familia ya existe.");

        var entity = new Familia { Codigo = dto.Codigo, Nombre = dto.Nombre, Activo = dto.Activo };
        _db.Familias.Add(entity);
        await _db.SaveChangesAsync();

        var result = new FamiliaDto(entity.IdFamilia, entity.Codigo, entity.Nombre, entity.Activo);
        return CreatedAtAction(nameof(GetById), new { id = entity.IdFamilia }, result);
    }

    [HttpPut("{id:int}")]
    public async Task<IActionResult> Put(int id, [FromBody] FamiliaCreateUpdateDto dto)
    {
        var f = await _db.Familias.FindAsync(id);
        if (f is null) return NotFound();

        if (await _db.Familias.AnyAsync(x => x.Codigo == dto.Codigo && x.IdFamilia != id))
            return Conflict("Código de familia ya existe.");

        f.Codigo = dto.Codigo; f.Nombre = dto.Nombre; f.Activo = dto.Activo;
        await _db.SaveChangesAsync();
        return NoContent();
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id)
    {
        var f = await _db.Familias.FindAsync(id);
        if (f is null) return NotFound();
        _db.Familias.Remove(f);
        await _db.SaveChangesAsync();
        return NoContent();
    }
}
