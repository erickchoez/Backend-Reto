﻿using backendReto.Data;
using backendReto.Dtos;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace backendReto.Controllers;

[ApiController]
[Route("api/[controller]")]
public class FacturasController : ControllerBase
{
    private readonly AppDbContext _db;
    private readonly IInvoiceService _service;
    public FacturasController(AppDbContext db, IInvoiceService service)
    { _db = db; _service = service; }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<FacturaResponseDto>>> Get()
    {
        var list = await _db.Facturas
            .Include(f => f.Items)
            .OrderByDescending(f => f.IdFactura)
            .Select(f => new FacturaResponseDto(
                f.IdFactura, f.NumeroFactura, f.RucCliente, f.RazonSocial,
                f.Subtotal, f.PorcentajeIGV, f.IGV, f.Total, f.FechaCreacion,
                f.Items.Select(i => new FacturaItemResponseDto(
                    i.IdItem, i.CodigoProducto, i.NombreProducto, i.Precio, i.Cantidad, i.Subtotal))
            ))
            .ToListAsync();

        return Ok(list);
    }

    [HttpPost]
    public async Task<ActionResult<FacturaResponseDto>> Post([FromBody] FacturaCreateDto dto)
    {
        var factura = await _service.CrearFacturaAsync(dto);

        var result = new FacturaResponseDto(
            factura.IdFactura, factura.NumeroFactura, factura.RucCliente, factura.RazonSocial,
            factura.Subtotal, factura.PorcentajeIGV, factura.IGV, factura.Total, factura.FechaCreacion,
            factura.Items.Select(i => new FacturaItemResponseDto(
                i.IdItem, i.CodigoProducto, i.NombreProducto, i.Precio, i.Cantidad, i.Subtotal))
        );

        return CreatedAtAction(nameof(Get), new { id = factura.IdFactura }, result);
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id)
    {
        var f = await _db.Facturas
            .Include(x => x.Items)
            .FirstOrDefaultAsync(x => x.IdFactura == id);

        if (f is null) return NotFound();

        
        foreach (var item in f.Items)
        {
            var producto = await _db.Productos
                .FirstOrDefaultAsync(p => p.Codigo == item.CodigoProducto);

            if (producto != null)
            {
                producto.Stock += item.Cantidad;
                _db.Productos.Update(producto);
            }
        }

        _db.FacturaItems.RemoveRange(f.Items);
        _db.Facturas.Remove(f);
        await _db.SaveChangesAsync();

        return NoContent();
    }
}
