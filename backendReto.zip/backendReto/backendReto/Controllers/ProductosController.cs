﻿using backendReto.Data;
using backendReto.Dtos;
using backendReto.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace backendReto.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ProductosController : ControllerBase
{
    private readonly AppDbContext _db;
    public ProductosController(AppDbContext db) => _db = db;

    [HttpGet]
    public async Task<ActionResult<IEnumerable<ProductoDto>>> Get()
        => Ok(await _db.Productos
            .Select(p => new ProductoDto(p.IdProducto, p.Codigo, p.Nombre, p.IdFamilia, p.Precio, p.Stock, p.Activo))
            .ToListAsync());

    [HttpGet("{id:int}")]
    public async Task<ActionResult<ProductoDto>> GetById(int id)
    {
        var p = await _db.Productos.FindAsync(id);
        return p is null
            ? NotFound()
            : Ok(new ProductoDto(p.IdProducto, p.Codigo, p.Nombre, p.IdFamilia, p.Precio, p.Stock, p.Activo));
    }

    [HttpPost]
    public async Task<ActionResult<ProductoDto>> Post([FromBody] ProductoCreateUpdateDto dto)
    {
        if (await _db.Productos.AnyAsync(x => x.Codigo == dto.Codigo))
            return Conflict("Código de producto ya existe.");

        var p = new Producto
        {
            Codigo = dto.Codigo,
            Nombre = dto.Nombre,
            IdFamilia = dto.IdFamilia,
            Precio = dto.Precio,
            Stock = dto.Stock,
            Activo = dto.Activo
        };
        _db.Productos.Add(p);
        await _db.SaveChangesAsync();

        var result = new ProductoDto(p.IdProducto, p.Codigo, p.Nombre, p.IdFamilia, p.Precio, p.Stock, p.Activo);
        return CreatedAtAction(nameof(GetById), new { id = p.IdProducto }, result);
    }

    [HttpPut("{id:int}")]
    public async Task<IActionResult> Put(int id, [FromBody] ProductoCreateUpdateDto dto)
    {
        var p = await _db.Productos.FindAsync(id);
        if (p is null) return NotFound();

        if (await _db.Productos.AnyAsync(x => x.Codigo == dto.Codigo && x.IdProducto != id))
            return Conflict("Código de producto ya existe.");

        p.Codigo = dto.Codigo;
        p.Nombre = dto.Nombre;
        p.IdFamilia = dto.IdFamilia;
        p.Precio = dto.Precio;
        p.Stock = dto.Stock;
        p.Activo = dto.Activo;
        await _db.SaveChangesAsync();

        return NoContent();
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id)
    {
        var p = await _db.Productos.FindAsync(id);
        if (p is null) return NotFound();
        _db.Productos.Remove(p);
        await _db.SaveChangesAsync();
        return NoContent();
    }
}
