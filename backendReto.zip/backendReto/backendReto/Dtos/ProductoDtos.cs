﻿using System.ComponentModel.DataAnnotations;

namespace backendReto.Dtos;

public record ProductoDto(int IdProducto, string Codigo, string Nombre, int IdFamilia, decimal Precio, int Stock, bool Activo);

public class ProductoCreateUpdateDto
{
    [Required, MaxLength(15)]
    public string Codigo { get; set; } = string.Empty;

    [Required, MaxLength(200)]
    public string Nombre { get; set; } = string.Empty;

    [Range(1, int.MaxValue)]
    public int IdFamilia { get; set; }

    [Range(0.01, double.MaxValue)]
    public decimal Precio { get; set; }

    [Range(0, int.MaxValue)]
    public int Stock { get; set; }

    public bool Activo { get; set; } = true;
}
