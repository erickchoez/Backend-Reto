﻿using System.ComponentModel.DataAnnotations;

namespace backendReto.Dtos;

public record FamiliaDto(int IdFamilia, string Codigo, string Nombre, bool Activo);

public class FamiliaCreateUpdateDto
{
    [Required, MaxLength(15)]
    public string Codigo { get; set; } = string.Empty;

    [Required, MaxLength(200)]
    public string Nombre { get; set; } = string.Empty;

    public bool Activo { get; set; } = true;
}
