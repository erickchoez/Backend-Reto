﻿using System.ComponentModel.DataAnnotations;

namespace backendReto.Dtos;

public class FacturaItemCreateDto
{
    [Required, MaxLength(15)]
    public string CodigoProducto { get; set; } = string.Empty;

    [Range(1, int.MaxValue)]
    public int Cantidad { get; set; } = 1;
}

public class FacturaCreateDto
{
    [Required, MaxLength(20)]
    public string RucCliente { get; set; } = string.Empty;

    [Required, MaxLength(200)]
    public string RazonSocial { get; set; } = string.Empty;

    [Range(0, 100)]
    public decimal PorcentajeIGV { get; set; }

    [MinLength(1)]
    public List<FacturaItemCreateDto> Items { get; set; } = new();
}

public record FacturaResponseDto(
    int IdFactura,
    long NumeroFactura,
    string RucCliente,
    string RazonSocial,
    decimal Subtotal,
    decimal PorcentajeIGV,
    decimal IGV,
    decimal Total,
    DateTime FechaCreacion,
    IEnumerable<FacturaItemResponseDto> Items
);

public record FacturaItemResponseDto(
    int IdItem,
    string CodigoProducto,
    string NombreProducto,
    decimal Precio,
    int Cantidad,
    decimal Subtotal
);
