﻿using System.ComponentModel.DataAnnotations;

namespace backendReto.Dtos;

public record LoginRequestDto(
    [Required, MaxLength(50)] string Username,
    [Required] string Password
);

public record LoginResponseDto(string Message);


public record RegisterRequestDto(
    [Required, MaxLength(50)] string Username,
    [Required] string Password);
public record RegisterResponseDto(string Message);