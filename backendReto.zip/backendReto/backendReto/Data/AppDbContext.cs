﻿using backendReto.Models;
using Microsoft.EntityFrameworkCore;

namespace backendReto.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<Usuario> Usuarios => Set<Usuario>();
    public DbSet<Familia> Familias => Set<Familia>();
    public DbSet<Producto> Productos => Set<Producto>();
    public DbSet<Factura> Facturas => Set<Factura>();
    public DbSet<FacturaItem> FacturaItems => Set<FacturaItem>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // Usuarios
        modelBuilder.Entity<Usuario>(e =>
        {
            e.HasIndex(x => x.Username).IsUnique();
        });

        // Familias
        modelBuilder.Entity<Familia>(e =>
        {
            e.HasIndex(x => x.Codigo).IsUnique();
            e.Property(x => x.FechaCreacion).HasDefaultValueSql("SYSUTCDATETIME()");
        });

        // Productos
        modelBuilder.Entity<Producto>(e =>
        {
            e.HasIndex(x => x.Codigo).IsUnique();
            e.Property(x => x.Precio).HasColumnType("decimal(18,2)");
            e.Property(x => x.FechaCreacion).HasDefaultValueSql("SYSUTCDATETIME()");
            e.HasOne(x => x.Familia).WithMany(f => f.Productos).HasForeignKey(x => x.IdFamilia);
        });

        // Facturas
        modelBuilder.Entity<Factura>(e =>
        {
            e.Property(x => x.NumeroFactura).HasDefaultValueSql("NEXT VALUE FOR dbo.SeqFactura");
            e.Property(x => x.Subtotal).HasColumnType("decimal(18,2)");
            e.Property(x => x.IGV).HasColumnType("decimal(18,2)");
            e.Property(x => x.Total).HasColumnType("decimal(18,2)");
        });

        // Items
        modelBuilder.Entity<FacturaItem>(e =>
        {
            e.Property(x => x.Precio).HasColumnType("decimal(18,2)");
            e.Property(x => x.Subtotal).HasColumnType("decimal(18,2)");
            e.HasOne(x => x.Factura).WithMany(f => f.Items).HasForeignKey(x => x.IdFactura)
             .OnDelete(DeleteBehavior.Cascade);
        });

        base.OnModelCreating(modelBuilder);
    }
}
