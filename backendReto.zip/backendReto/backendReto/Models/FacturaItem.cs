﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using backendReto.Models;

namespace backendReto.Models;

public class FacturaItem
{
    [Key]
    public int IdItem { get; set; }

    [ForeignKey(nameof(Factura))]
    public int IdFactura { get; set; }
    public Factura? Factura { get; set; }

    [Required, MaxLength(15)]
    public string CodigoProducto { get; set; } = string.Empty;

    [Required, MaxLength(200)]
    public string NombreProducto { get; set; } = string.Empty;

    [Range(0.01, double.MaxValue)]
    public decimal Precio { get; set; }

    [Range(1, int.MaxValue)]
    public int Cantidad { get; set; }

    [Range(0.01, double.MaxValue)]
    public decimal Subtotal { get; set; }
}
