﻿using System.ComponentModel.DataAnnotations;

namespace backendReto.Models;

public class Factura
{
    [Key]
    public int IdFactura { get; set; }

    
    public long NumeroFactura { get; set; }

    [Required, MaxLength(20)]
    public string RucCliente { get; set; } = string.Empty;

    [Required, MaxLength(200)]
    public string RazonSocial { get; set; } = string.Empty;

    [Range(0, double.MaxValue)]
    public decimal Subtotal { get; set; }

    [Range(0, 100)]
    public decimal PorcentajeIGV { get; set; }

    [Range(0, double.MaxValue)]
    public decimal IGV { get; set; }

    [Range(0, double.MaxValue)]
    public decimal Total { get; set; }

    public DateTime FechaCreacion { get; set; } = DateTime.UtcNow;

    public ICollection<FacturaItem> Items { get; set; } = new List<FacturaItem>();
}
