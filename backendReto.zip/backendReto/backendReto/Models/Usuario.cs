﻿using System.ComponentModel.DataAnnotations;

namespace backendReto.Models;

public class Usuario
{
    [Key]
    public int IdUsuario { get; set; }

    [Required, MaxLength(50)]
    public string Username { get; set; } = string.Empty;

    [Required]
    public string PasswordHash { get; set; } = string.Empty;
    public bool Activo { get; set; } = true;

    public int IntentosFallidos { get; set; } = 0;

    public bool Bloqueado { get; set; } = false;

    public DateTime FechaCreacion { get; set; } = DateTime.UtcNow;
}
