﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using backendReto.Models;

namespace backendReto.Models;

public class Producto
{
    [Key]
    public int IdProducto { get; set; }

    [Required, MaxLength(15)]
    public string Codigo { get; set; } = string.Empty;

    [Required, MaxLength(200)]
    public string Nombre { get; set; } = string.Empty;

    [ForeignKey(nameof(Familia))]
    public int IdFamilia { get; set; }
    public Familia? Familia { get; set; }

    [Range(0.01, double.MaxValue)]
    public decimal Precio { get; set; }

    [Range(0, int.MaxValue)]
    public int Stock { get; set; }

    public bool Activo { get; set; } = true;

    public DateTime FechaCreacion { get; set; } = DateTime.UtcNow;
}
