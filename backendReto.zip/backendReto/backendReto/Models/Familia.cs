﻿using System.ComponentModel.DataAnnotations;

namespace backendReto.Models;

public class Familia
{
    [Key]
    public int IdFamilia { get; set; }

    [Required, MaxLength(15)]
    public string Codigo { get; set; } = string.Empty;

    [Required, MaxLength(200)]
    public string Nombre { get; set; } = string.Empty;

    public bool Activo { get; set; } = true;

    public DateTime FechaCreacion { get; set; } = DateTime.UtcNow;

    public ICollection<Producto> Productos { get; set; } = new List<Producto>();
}
