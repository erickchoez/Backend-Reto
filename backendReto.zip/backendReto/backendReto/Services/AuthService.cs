﻿using backendReto.Dtos;
using backendReto.Models;
using Microsoft.EntityFrameworkCore;

namespace backendReto.Data;

public class AuthService : IAuthService
{
    private readonly AppDbContext _db;
    public AuthService(AppDbContext db) => _db = db;


    // Iniciar sesion
 
    public async Task<LoginResponseDto> LoginAsync(LoginRequestDto dto)
    {
        var user = await _db.Usuarios.FirstOrDefaultAsync(u => u.Username == dto.Username);
        if (user is null)
            throw new UnauthorizedAccessException("Credenciales inválidas.");

        if (user.Bloqueado)
            throw new UnauthorizedAccessException("Usuario bloqueado por intentos fallidos.");

        var ok = BCrypt.Net.BCrypt.Verify(dto.Password, user.PasswordHash);
        if (!ok)
        {
            user.IntentosFallidos += 1;
            if (user.IntentosFallidos >= 3)
                user.Bloqueado = true;

            await _db.SaveChangesAsync();
            throw new UnauthorizedAccessException($"Credenciales inválidas. Intentos: {user.IntentosFallidos}/3");
        }

        user.IntentosFallidos = 0;
        await _db.SaveChangesAsync();

        return new LoginResponseDto("Login exitoso.");
    }


    // Registrar
    public async Task<RegisterResponseDto> RegisterAsync(RegisterRequestDto dto)
    {
        // Validar si el usuario ya existe
        var exists = await _db.Usuarios.AnyAsync(u => u.Username == dto.Username);
        if (exists)
            throw new InvalidOperationException("El nombre de usuario ya está en uso.");

        // Hashear contraseña
        var hashedPassword = BCrypt.Net.BCrypt.HashPassword(dto.Password);

        var user = new Usuario
        {
            Username = dto.Username,
            PasswordHash = hashedPassword,
            Activo = true,
            IntentosFallidos = 0,
            Bloqueado = false
        };

        _db.Usuarios.Add(user);
        await _db.SaveChangesAsync();

        return new RegisterResponseDto("Usuario registrado exitosamente.");
    }
}
