﻿using backendReto.Dtos;

namespace backendReto.Data;

public interface IAuthService
{
    Task<LoginResponseDto> LoginAsync(LoginRequestDto dto);
    Task<RegisterResponseDto> RegisterAsync(RegisterRequestDto dto);
}
