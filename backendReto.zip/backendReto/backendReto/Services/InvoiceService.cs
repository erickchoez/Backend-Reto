﻿using backendReto.Dtos;
using backendReto.Models;
using Microsoft.EntityFrameworkCore;

namespace backendReto.Data;

public class InvoiceService : IInvoiceService
{
    private readonly AppDbContext _db;
    public InvoiceService(AppDbContext db) => _db = db;

    public async Task<Factura> CrearFacturaAsync(FacturaCreateDto dto)
    {
        using var tx = await _db.Database.BeginTransactionAsync();

        if (dto.Items == null || dto.Items.Count == 0)
            throw new ArgumentException("La factura debe tener al menos un ítem.");

        // Cargar productos por código
        var codigos = dto.Items.Select(i => i.CodigoProducto).ToList();
        var productos = await _db.Productos
            .Where(p => codigos.Contains(p.Codigo))
            .ToDictionaryAsync(p => p.Codigo);

        var items = new List<FacturaItem>();
        decimal subtotal = 0m;

        foreach (var it in dto.Items)
        {
            if (!productos.TryGetValue(it.CodigoProducto, out var prod))
                throw new InvalidOperationException($"Producto {it.CodigoProducto} no existe.");

            if (it.Cantidad <= 0) throw new InvalidOperationException("Cantidad debe ser > 0.");
            if (prod.Precio <= 0) throw new InvalidOperationException("Precio del producto no puede ser 0.");
            if (prod.Stock < it.Cantidad) throw new InvalidOperationException($"Stock insuficiente de {prod.Codigo}.");

            var sub = prod.Precio * it.Cantidad;
            subtotal += sub;

            items.Add(new FacturaItem
            {
                CodigoProducto = prod.Codigo,
                NombreProducto = prod.Nombre,
                Precio = prod.Precio,
                Cantidad = it.Cantidad,
                Subtotal = sub
            });

            // descontar stock
            prod.Stock -= it.Cantidad;
        }

        var igv = Math.Round(subtotal * (dto.PorcentajeIGV / 100m), 2);
        var total = Math.Round(subtotal + igv, 2);

        var factura = new Factura
        {
            RucCliente = dto.RucCliente,
            RazonSocial = dto.RazonSocial,
            Subtotal = Math.Round(subtotal, 2),
            PorcentajeIGV = dto.PorcentajeIGV,
            IGV = igv,
            Total = total,
            Items = items
        };

        _db.Facturas.Add(factura);
        await _db.SaveChangesAsync();
        await tx.CommitAsync();

        return factura;
    }
}
