﻿using backendReto.Dtos;
using backendReto.Models;

namespace backendReto.Data;

public interface IInvoiceService
{
    Task<Factura> CrearFacturaAsync(FacturaCreateDto dto);
}
